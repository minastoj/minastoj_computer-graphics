Assignment #3: Ray tracing

FULL NAME: Mina Stojanovic


MANDATORY FEATURES
------------------

<Under "Status" please indicate whether it has been implemented and is
functioning correctly.  If not, please explain the current status.>

Feature:                                 Status: finish? (yes/no)
-------------------------------------    -------------------------
1) Ray tracing triangles                  YES

2) Ray tracing sphere                     YES

3) Triangle Phong Shading                 YES

4) Sphere Phong Shading                   YES

5) Shadows rays                           YES

6) Still images                           YES
   
7) Extra Credit (up to 20 points)

   ANIMATION: I implemented an animation made up of 16 frames in the folder called "Animation." It's a depiction a circle going around the screen in a unit circle pattern and changing colors in the order of the colors of the rainbow. There is also a video representation of this called "animation.mp4." (The regular test images that we were given have been rendered as well and are in the folder titled "Supplied Scene Renders.")

   SOFT SHADOWS: I implemented soft shadows for my Ray Tracer as well! Not much more to say here :)
